import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const ChukApp());

class ChukApp extends StatelessWidget {
  const ChukApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'CHUK by Viraat Jarsoniya',
    theme: ThemeData(
      useMaterial3: true,
      colorSchemeSeed: Colors.amber,
      brightness: Brightness.dark,
    ),
    home: const ChukHome(),
  );
}

class ChukHome extends StatefulWidget {
  const ChukHome({super.key});
  @override State<ChukHome> createState() => _ChukHomeState();
}

class _ChukHomeState extends State<ChukHome> {
  final random = Random();
  final ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  final suits = ['♠','♥','♦','♣'];
  int players = 2, p1 = 0, p2 = 0, p3 = 0;
  List<String> hand = [];
  final selected = <int>{};
  bool dealt = false, gameOver = false;

  void deal() {
    final deck = [for (final s in suits) for (final r in ranks) '$r$s']..shuffle(random);
    setState(() {
      hand = deck.take(17).toList();
      selected.clear();
      dealt = true;
      gameOver = false;
    });
  }

  void finishRound() {
    if (selected.length != 2) return;
    int a = 0, b = 0, c = 0;
    for (int i = 0; i < 5; i++) {
      final winner = random.nextInt(players);
      if (winner == 0) a++;
      if (winner == 1) b++;
      if (winner == 2) c++;
    }
    setState(() {
      p1 += a; p2 += b; p3 += c; dealt = false;
    });
    final winner = p1 >= 25 ? 0 : p2 >= 25 ? 1 : (players == 3 && p3 >= 25 ? 2 : -1);
    if (winner >= 0) {
      gameOver = true;
      Future.microtask(() => showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('🏆 CHUK Winner'),
          content: Text('Player ${winner + 1} ने 25 points पूरे किए!'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      ));
    }
  }

  void reset() => setState(() {
    p1 = p2 = p3 = 0; hand = []; selected.clear(); dealt = false; gameOver = false;
  });

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      centerTitle: true,
      title: const Column(children: [
        Text('🃏 CHUK', style: TextStyle(fontWeight: FontWeight.bold)),
        Text('by Viraat Jarsoniya', style: TextStyle(fontSize: 12)),
      ]),
    ),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(
        padding: const EdgeInsets.all(14),
        child: SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 2, label: Text('2 Players')),
            ButtonSegment(value: 3, label: Text('3 Players')),
          ],
          selected: {players},
          onSelectionChanged: (v) => setState(() => players = v.first),
        ),
      )),
      Row(children: [
        _score('P1', p1), _score('P2', p2), if (players == 3) _score('P3', p3),
      ]),
      const SizedBox(height: 8),
      FilledButton.icon(
        onPressed: gameOver ? null : deal,
        icon: const Icon(Icons.style),
        label: const Text('17 Cards Deal'),
      ),
      if (dealt) ...[
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Text('2 extra cards चुनकर बाहर करें', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (int i = 0; i < hand.length; i++)
            InkWell(
              onTap: () => setState(() {
                if (selected.contains(i)) {
                  selected.remove(i);
                } else if (selected.length < 2) {
                  selected.add(i);
                }
              }),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 11),
                decoration: BoxDecoration(
                  color: selected.contains(i) ? Colors.amber : Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(hand[i], style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
              ),
            ),
        ]),
        const SizedBox(height: 10),
        FilledButton(
          onPressed: selected.length == 2 ? finishRound : null,
          child: Text('Discard ${selected.length}/2'),
        ),
      ],
      OutlinedButton(onPressed: reset, child: const Text('New Match')),
      const Card(child: Padding(
        padding: EdgeInsets.all(14),
        child: Text('Rules: 17 cards → 2 discard → 15 cards → 5 sets. First to 25 points wins. Four same-rank cards: higher rank gets +5.'),
      )),
      const Card(child: ListTile(leading: Icon(Icons.public), title: Text('Random Online'), subtitle: Text('Online backend integration pending'))),
      const Card(child: ListTile(leading: Icon(Icons.group), title: Text('Friends / Private Room'), subtitle: Text('Backend integration pending'))),
      const Card(child: ListTile(leading: Icon(Icons.mic), title: Text('Voice Chat'), subtitle: Text('Voice service integration pending'))),
    ]),
  );

  Expanded _score(String name, int score) => Expanded(
    child: Card(child: Padding(
      padding: const EdgeInsets.all(8),
      child: Column(children: [
        Text(name),
        Text('$score / 25', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ]),
    )),
  );
}
