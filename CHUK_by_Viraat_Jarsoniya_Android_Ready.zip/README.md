# CHUK by Viraat Jarsoniya

Android-ready Flutter project structure.

After importing into a Flutter cloud build service:
flutter pub get
flutter build apk --release

Important: this is a build-ready starter/prototype. Live multiplayer, voice chat, friends, authentication, and production scoring/backend still need implementation. No real-money wagering is included.
