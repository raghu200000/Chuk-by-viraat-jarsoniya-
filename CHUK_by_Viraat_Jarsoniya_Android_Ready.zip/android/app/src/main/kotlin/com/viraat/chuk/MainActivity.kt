package com.viraat.chuk
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
